create sequence SEQ_FRAMEWORK_SYS_MENU
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;

create sequence SEQ_FRAMEWORK_SYS_PERMISSION
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;

create sequence SEQ_FRAMEWORK_SYS_ROLE
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;
create sequence SEQ_FRAMEWORK_USER_ROLE
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;
create sequence SEQ_FRAMEWORK_PERM_ASSIGN
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;
create sequence SEQ_FRAMEWORK_USER_INF
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;
create sequence SEQ_FRAMEWORK_ACTION_LOG
minvalue 1
maxvalue 9999999999999999999999999999
start with 300
increment by 1
cache 20;
