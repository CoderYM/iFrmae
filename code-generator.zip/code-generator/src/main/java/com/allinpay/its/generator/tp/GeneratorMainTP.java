package com.allinpay.its.generator.tp;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import cn.org.rapid_framework.generator.GeneratorFacade;
import cn.org.rapid_framework.generator.GeneratorProperties;

/**
 * @author lz
 */

public class GeneratorMainTP {
	
	public static String tpName = "Bos";
	public static String tpBasePackage = "com.allinpay.its.tp.channel";
	
	/**
	 * 请直接修改以下代码调用不同的方法以执行相关生成任务.
	 */
	public static void main(String[] args) throws Exception {
		
		GeneratorFacade g = new GeneratorFacade();
		String template = "template_tp";
		
		g.deleteOutRootDir();//删除生成器的输出目录
		
		//自定义变量
		Map<String,String> map = new HashMap<String,String>();
		map.put("TpName", tpName);
		map.put("basepackage", tpBasePackage + "." + tpName.toLowerCase());//包全名
		map.put("basepackage_dir", (tpBasePackage + "." + tpName.toLowerCase()).replaceAll("\\.","/"));//包地址
		map.put("supportedChannels", "${" + tpName + ".supportedChannels}");
		
		map.put("author", "yourname");
		map.put("date", new SimpleDateFormat("yyyy-MM-dd").format(new Date()));//为获取当前系统时间
		
		g.generateByMap(map, template);
		
		Runtime.getRuntime().exec("cmd.exe /c start "+GeneratorProperties.getRequiredProperty("outRoot"));
	}
}
